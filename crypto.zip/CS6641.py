
import math
dict={}

for i in range(102,118):
    dict[chr(i)]=0
iter=1
p=[23, 75, 97, 119, 81, 86, 71, 45, 51, 60, 92, 29, 37, 89, 42, 106, 41, 6, 51, 33, 58, 2, 27, 57, 50, 37, 62, 58, 6, 80, 122, 68]
abs=[]
while p[0]>0:
    
    abs=[]
    e=[1]
    for k in range(1,p[0]+1):
        sign=1
        ans=0
        for j in range(1,k+1):
            ans+=((sign)*((e[k-j])*(p[j])))%127
            sign*=-1

        ans=ans%127
        for gg in range(127):
            if (gg*k)%127==ans:
                ans=gg
                break
        e.append(ans)


    for j in range(p[0]):
        e[j]%=127

    #print(e)

    for j in range(102,118):
        
        ans=0
        sign=1
        for i in range(p[0]+1):
            val_exp=(pow(j,p[0]-i))
            ans=ans+(e[i]*sign*val_exp)
            ans=ans
            sign*=-1
        ans=ans%127

        if(ans==0):
            dict[chr(j)]+=1
            abs.append(j)
    aks=[]
    for i in abs:
        aks.append(chr(i))
    print(len(abs),"solutions found in iteration",iter,":", aks)
    p[0]-=len(abs)
    # print(p[0])
    for i in range(p[0]):
        for j in range(len(abs)):
            p[i+1]=p[i+1]-pow(abs[j],i+1)%127
            p[i+1]%=127
    #break
    iter+=1

print("All solutions:",dict)
string=""
for i in range(102,118):
    v=dict[chr(i)]
    for u in range(v):
        string=string+str(chr(i))
print("passwd:", string)
#print(len(string))
